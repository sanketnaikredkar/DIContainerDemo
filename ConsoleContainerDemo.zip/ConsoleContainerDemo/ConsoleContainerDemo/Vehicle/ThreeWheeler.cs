﻿using System;
using ConsoleContainerDemo.Interfaces;
using Unity.Injection;

namespace ConsoleContainerDemo.Vehicle
{
    public class ThreeWheeler : IVehicle
    {
        public string Run()
        {
            return "ThreeWheeler: Driving 3 wheeler vehicle";
        }
    }
}
