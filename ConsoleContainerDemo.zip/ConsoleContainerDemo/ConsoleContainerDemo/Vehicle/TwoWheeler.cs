﻿using System;
using ConsoleContainerDemo.Interfaces;

namespace ConsoleContainerDemo.Vehicle
{
    public class TwoWheeler : IVehicle
    {
        public string Run()
        {
            return "TwoWheeler: Driving 2 wheeler vehicle";
        }

    }
}
