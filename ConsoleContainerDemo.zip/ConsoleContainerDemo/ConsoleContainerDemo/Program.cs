﻿using Microsoft.Practices.Unity.Configuration;
using System;
using System.Configuration;
using ConsoleContainerDemo.Interfaces;
using ConsoleContainerDemo.Vehicle;
using Unity;
using Unity.Injection;

namespace ConsoleContainerDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            CodeMethod();
            XmlConfigMethod();
        }

        private static void XmlConfigMethod()
        {
            Driver driver;
            var container = new UnityContainer();
            UnityConfigurationSection section = (UnityConfigurationSection)ConfigurationManager.GetSection("unity");
            container.LoadConfiguration(section);
            container.RegisterType<Driver>("TwoWheelerDrive", new InjectionConstructor(container.Resolve<IVehicle>("TwoWheeler")));
            container.RegisterType<Driver>("ThreeWheelerDrive", new InjectionConstructor(container.Resolve<IVehicle>("ThreeWheeler")));

            Console.WriteLine("Welcome to the vehicle showroom.\nPlease choose the vehicle type....\n2.Two wheeler \n3.Three wheeler\n===============================");

            switch (Convert.ToInt16(Console.ReadLine()))
            {
                case 2:
                    driver = container.Resolve<Driver>("TwoWheelerDrive"); //instantiate TwoWheeler() class 
                    Console.WriteLine(driver.NotifyRunMethod());
                    break;
                case 3:
                    driver = container.Resolve<Driver>("ThreeWheelerDrive");//instantiate ThreeWheeler() class
                    Console.WriteLine(driver.NotifyRunMethod());
                    break;
                default:
                    Console.WriteLine("invalid input");
                    break;
            }
            container.Dispose();
            Console.ReadKey();
        }

        private static void CodeMethod()
        {
            Driver driver;
            var container = new UnityContainer();
            container.RegisterType<IVehicle, TwoWheeler>("TwoWheeler");
            container.RegisterType<IVehicle, ThreeWheeler>("ThreeWheeler");
            container.RegisterType<Driver>("TwoWheelerDrive", new InjectionConstructor(container.Resolve<IVehicle>("TwoWheeler")));
            container.RegisterType<Driver>("ThreeWheelerDrive", new InjectionConstructor(container.Resolve<IVehicle>("ThreeWheeler")));

            Console.WriteLine("Welcome to the vehicle showroom.\nPlease choose the vehicle type....\n2.Two wheeler \n3.Three wheeler\n===============================");

            switch (Convert.ToInt16(Console.ReadLine()))
            {
                case 2:
                    driver = container.Resolve<Driver>("TwoWheelerDrive"); //instantiate TwoWheeler() class 
                    Console.WriteLine(driver.NotifyRunMethod());
                    break;
                case 3:
                    driver = container.Resolve<Driver>("ThreeWheelerDrive");//instantiate ThreeWheeler() class
                    Console.WriteLine(driver.NotifyRunMethod());
                    break;
                default:
                    Console.WriteLine("invalid input");
                    break;
            }
            container.Dispose();
            Console.ReadKey();
        }
    }
}
