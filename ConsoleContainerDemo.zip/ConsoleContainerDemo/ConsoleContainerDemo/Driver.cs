﻿using ConsoleContainerDemo.Interfaces;

namespace ConsoleContainerDemo
{
    public class Driver
    {
        private IVehicle _vehicle;
        public Driver(IVehicle vehicle)
        {
            _vehicle = vehicle;
        }

        public string NotifyRunMethod()
        {
            return _vehicle.Run();
        }
    }
}
